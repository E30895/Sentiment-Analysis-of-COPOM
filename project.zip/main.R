library(tidyverse)
library(jsonlite)
library(curl)
library(pdftools)
library(tm)
library(tidytext)
library(textdata)
library(scales)
library(ggtext)


source('get_atas.R')
source('get_transform_atas.R')
source('get_Loughran_McDonald.R')
source('get_sentiment_analysis.R')
source('get_graphics.R')


############################## NPL ###########################

atas = get_atas()
atas_token = get_transform_atas(atas)
Loughran_McDonald = get_Loughran_McDonald()
sentiment_analysis = get_sentiment_analysis(atas_token, Loughran_McDonald)
grafico_ts = get_graphics(sentiment_analysis)


################################## ECONOMETRICS ################################

library(rbcb)
library(xts)
library(zoo)
library(tsibble)
library(lubridate)

source('get_series.R')
source('get_compiled.R')

series = get_series(sentiment_analysis)
data = get_compiled(series)


selic = series$selic
ipca_variacao = series$ipca
sentiment = series$sentiment_analysis

#sentiment = sentiment[-2:-3]
#sentiment = xts::xts(sentiment$sentimento_copom, sentiment$data)


forecast::ndiffs(sentiment$sentimento_copom, test = ('adf'), type = 'level')
forecast::ndiffs(sentiment$sentimento_copom, test = ('adf'), type = 'trend')

forecast::ndiffs(ipca_variacao$ipca, test = ('adf'), type = 'level')
forecast::ndiffs(ipca_variacao$ipca, test = ('adf'), type = 'trend')

forecast::ndiffs(selic$selic, test = ('adf'), type = 'level')
forecast::ndiffs(selic$selic, test = ('adf'), type = 'trend')

urca::ur.df(sentiment$sentimento_copom, type = 'none')
urca::ur.df(sentiment$sentimento_copom, type = 'drift')
urca::ur.df(sentiment$sentimento_copom, type = 'trend')


selic = diff(selic)
sentiment = diff(sentiment)
############# RESULTADOS: SELIC NÃO ESTACIONÁRIA E DIFERENCIADA 


data_inicial <- lubridate::ym("2000-01")
data_atual <- Sys.Date() - lubridate::days(lubridate::day(Sys.Date()))
serie_temporal <- seq(data_inicial, data_atual, by = "1 month")

data = data.frame(date = seq(data_inicial, data_atual, by = "1 month"))
data$date = substr(data$date, 1, 7)

series = lapply(series, function(df, data_principal = data){
  
  df$date = as.Date(df$date)
  df$date = substr(df$date, 1, 7)
  
  df <- distinct(df, date, .keep_all = TRUE)
  
  return(df)
  
})

selic = series$selic_meta

# Cria a sequência de datas mensais desde 2000 até o mês anterior










VARselect(data, lag.max = 12, season=12, type='const')
dummies <- seasonaldummy(data[,1])
var <- VAR(data, 1, type='const', exogen = dummies)

roots(var) #RAIS UNITÁRIA

# Teste de autocorrelação
serial.test(var)

# Teste de normalidade
normality.test(var)

# Teste para heterocedasticidade
arch.test(var)

reccusum <- stability(var, type='OLS-CUSUM')

irf.inf <- irf(var, impulse='inflacao', response='selic', 
               n.ahead=12, ortho=F, cumulative = F, boot=F)
fevd.var <- fevd(var, n.ahead=12)

